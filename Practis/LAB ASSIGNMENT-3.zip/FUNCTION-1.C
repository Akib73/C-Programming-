//1. Write a function that takes one integer argument and returns its square.
#include<stdio.h>
int square(int b);
int main ()

{
int a;
printf("Enter a number : ");
scanf("%d",&a);
printf("square of the number is %d",square(a));
return 0;
}
int square(int b){
return b*b;
}
