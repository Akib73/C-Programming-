#include <stdio.h>
int main ()
{
char c;
printf("Input any Capital letter:\n");
scanf("%c",&c);
printf("small letter: %c",c+32);
return 0;
}
