//3. WAP to input the values in a two dimensional array of integers and display the values.
#include <stdio.h>
int main()
{
int a[2][3];
int i,j,k;
printf("Enter element of a[2][3] array:\n");
for(i=0;i<2;i++)
{
for(j=0; j<3;j++)
{
printf("Enter the element %d:",k++);
scanf("%d",&a[i][j]);
}}
printf("Elements of a[2][3] 2d array is:");
for(i=0;i<2;i++)
{
for(j=0;j<3;j++)
{
printf("%d",a[i][j]);
}
}
return 0;
}
