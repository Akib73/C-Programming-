//5. Write a function that returns 1 if the number is prime and 0 if not prime. Number is passed to the function as argument.
#include<stdio.h>
int prime(int a);
int main ()
{
int n,ans;
printf("Enter a number : ");
scanf("%d",&n);
ans=prime(n);
printf("If the number is prime result is 1 or result is 0:\nResult:%d",ans);
}
int prime(int a)
{
int i;
int flag=0;
for(i=2; i<a; i++){
if(a%i){
flag=1;
}
break;}
if(flag==0){
return 0;}
else{
return 1;}
}
