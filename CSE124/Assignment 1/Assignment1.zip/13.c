#include <stdio.h>
int main ()
{
char c;
printf("Input any character:\n");
scanf("%c",&c);
printf("ASCII number of this character:%d",c);
return 0;
}
