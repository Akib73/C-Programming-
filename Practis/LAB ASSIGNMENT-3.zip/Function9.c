//9. Write a recursive function that will find the GCD of two numbers.
#include <stdio.h>
int gcd(int a ,int b);
int main ()
{
int m,n,GCD;
printf("Enter first number : \n");
scanf("%d",&m);
printf("Enter secound number : \n");
scanf("%d",&n);
GCD=gcd(m,n);
printf("GCD=%d",GCD);
}
int gcd(int a ,int b)
{
if(b==0){
return a;
}
return (b,a%b);
}
