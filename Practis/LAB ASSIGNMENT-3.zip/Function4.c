/*4. Write a function to print the sum and average of first n odd numbers
where n is passed to the function as argument.*/
#include <stdio.h>
int sum_odd(int a);
int avg_odd(int b);
int main ()
{
int n,sum,avg;
printf("Enter  Number : ");
scanf("%d",&n);
sum=sum_odd(n);
avg=avg_odd(n);
printf("Sum of first odd number =%d,avg=%d",sum,avg);
}
int sum_odd(int a)
{int i,sum=0;
for(i=0; i<=a*2; i++)
    {
if(i%2)
{
sum=sum+i;
}}
return sum;}
int avg_odd(int b)
{
return sum_odd(b)/b;}
