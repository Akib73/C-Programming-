//5. WAP to reverse a string.
#include<string.h>
int main ()
{
    int i;
    char c[100];

    gets(c);
    int size=strlen(c);
    for(i=size-1; i>=0; i--)
    {
        printf("%c",c[i]);
    }
    return 0;
}
