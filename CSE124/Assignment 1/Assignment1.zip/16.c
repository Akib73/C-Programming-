#include <stdio.h>
int main ()
{
char c;
printf("Input any Small letter:\n");
scanf("%c",&c);
printf("Capital letter:%c",c-32);
return 0;
}
