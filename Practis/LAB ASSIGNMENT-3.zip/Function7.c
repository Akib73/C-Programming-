/*7. Write a program to take two numbers as input and function to swap them
by passing parameters as values and also as addresses.*/
#include <stdio.h>
void swap(float a,float b);
int main()
{
float m,n;
printf("Enter First values: ");
scanf("%f",&m);
printf("Enter Second  values: ");
scanf("%f",&n);
printf("Before swap value :\nFirst value=%g\nSecond value=%g\n",m,n);
swap(m,n);
}
void swap(float a,float b)
{
float temp;
temp=a;
a=b;
b=temp;
printf("After swap value:\nFirst value=%g\nSecond value=%g",a,b);
}
