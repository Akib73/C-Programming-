//2. Write a function to calculate the area of a circle where radius is passed to the function as argument.
#include <stdio.h>
double pi();
double area_circle(double r);
void pf();
int main ()
{
double a,Area;
pf();
scanf("%lf",&a);
Area=area_circle(a);
printf("Area of the circle is %lf",Area);
}
void pf()
{
printf("Enter  redius: ");
}
double pi()
{
return 3.1416;
}
double area_circle(double r)
{
return pi(r)*r*r;
}
