#include <stdio.h>
int main ()
{
printf("Name: Akib Ahamad Imu\n");
printf("Father Name: MD.Entaz Ali\n");
printf("Mother Name: Aysha Akther Lucky");
return 0;
}
