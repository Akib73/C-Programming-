//6. WAP to input a string and replace every lower case letter  with upper case letter,
//upper   case letter with a lower case letter,
//digit with a �#� and a special  symbol with a �%�. Display the new string.

#include <string.h>
int main ()
{
char c[100];
gets(c);
int i,v=0, n=0, d=0, s=0,k=0;
int size =strlen(c);
for(i=0; i<size; i++){
if(c[i]>='a' && c[i]<='z'){
printf("%c",c[i]-=32);}
else if (c[i]>='A' && c[i]<='Z'){
printf("%c",c[i]+=32);}
else if (c[i]>='0' && c[i]<='9'){
printf("#");}
else if(c[i]==' ') {
printf(" ");}
else {
printf("%%");}}
return 0;
}
