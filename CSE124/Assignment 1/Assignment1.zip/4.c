#include <stdio.h>
int main ()
{
int a,b,s;
printf("Enter tow integer number\n");
scanf("%d%d",&a,&b);
s=a+b;
printf("Sum of two integer numbers =%d",s);
return 0;
}
