#include <stdio.h>
int main ()
{
int a,b;
a=10;
b=20;
printf("Sum of a and b= %d",a+b);
return 0;
}
