/*3. Write a function that has one character argument
and displays that it�s a small letter, capital letter, a digit or a special symbol. */
#include <stdio.h>
void determine(char c);
int main ()
{
char a;
scanf("%c",&a);
determine(a);
}
void determine (char c)
{
if(c>='a'&& c<='z')
    {
printf("It is a Small latter");
}
else if (c>='A'&& c<='Z')
    {
printf("It is a Capital letter");
}
else if(c>='0' && c<='9')
    {
printf("It is a digit");
}
else
    {
printf("It is a Special Symbol");
}
}



