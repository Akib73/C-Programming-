#include <stdio.h>
int main()
{
int a;
printf(" Input any ASCII number:\n");
scanf("%d",&a);
printf("Appropriate character of the ASCII value is:%c",a);
return 0;
}
