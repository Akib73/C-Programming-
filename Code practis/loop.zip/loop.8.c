#include <stdio.h>
int main ()
{
int base ,power,a=1;
printf("Enter Base:\n");
scanf("%d",&base);
printf("Enter Power:\n");
scanf("%d",&power);
int i;
for(i=1; i<=power; i++){
a=a*base;}
printf("%d^%d=%d",base,power,a);
return 0;
}
