#include <stdio.h>
int main ()
{
int i,s;
printf("Enter a number:\n");
scanf("%d",&s);
for(i=2; i<10; i++){
if(s%i==0)
printf("It is not");
break;
 }
printf("It is a prime number ");
return 0;
}
