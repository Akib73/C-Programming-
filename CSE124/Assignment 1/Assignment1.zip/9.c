#include <stdio.h.>
int main ()
{
float c,f;
printf("Enter Celsius value :\n");
scanf("%f",&c);
f=c*9/5+32;
printf("Fahrenheit value=%g",f);
return 0;
}
