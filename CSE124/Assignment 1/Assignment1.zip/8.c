#include <stdio.h>
int main ()
{
float km;
int m;
printf("Enter Km value:\n");
scanf("%f",&km);
m=km*1000;
printf("%g Killometers =%d Mter",km,m);
return 0;
}
